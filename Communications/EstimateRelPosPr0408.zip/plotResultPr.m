function plotResultPr(r_ab, tVec, trueDir)
figure
hold on
sgtitle('Distance in each direction')
NEDvec=['N'; 'E'; 'D'];
for i=1:3
subplot(4,1,i)
plot(tVec,r_ab(i,:))
xlabel(strcat(NEDvec(i), '-direction, mean: ', ...
        num2str(mean(r_ab(i,:))) ...
))
end
subplot(414)
d=vecnorm(r_ab, 1);
plot(tVec,d)
xlabel('Euclidean distance')


labelVec = ['N-direction'; 'E-direction'; 'D-direction'];
numVec   = ['0', '1', '2'];
figure
sgtitle(strcat('Histogram drift relative estimates from pR, true distance 1.6m in ', trueDir, '-direction'))
for i=1:3
    subplot(3,1,i)
    histogram(r_ab(i,:)-mean(r_ab(i,:)),'Normalization','probability', 'DisplayStyle', 'stairs');
    hold on
    xlabel(strcat(labelVec(i,:),', mean 2= ', num2str(round(mean(r_ab(i,:)),2)), '[m]', ...
            ', \sigma^2= ', num2str(round(var(r_ab(i,:)),2))  ...
        ))
end