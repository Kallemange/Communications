function [s1shared, s2shared]=findSharedSV(s1,s2,t1,t2)
%At each time instance, find the satellites which are observed in both
%recievers.

%ISSUE, may be overlap, I will remove all duplicates of svID elements, will
%have to check that angles are the same later
s1shared=s1(t1);
s2shared=s2(t2);
%Create two structs to store previous reading, and update only in case a
%new reading is made
s1Prev=[];
s2Prev=[];
[~, i1, i2]          = intersect([s1(t1).ToW], [s2(t2).ToW]);
for i=1:length(i1)
        s1sortedID       = sortrows(s1(t1(i1(i))).data, 2);
        s2sortedID       = sortrows(s2(t2(i2(i))).data, 2);
        [~,idx1, idx2]   = intersect(s1sortedID.svID, s2sortedID.svID);
        s1shared(i).data = s1sortedID(idx1,:);
        s2shared(i).data = s2sortedID(idx2,:); 
        if (~all(s1shared(i).data.svID==s2shared(i).data.svID))
            keyboard
        end
end






% 
% for i=1:min(length(t1), length(t2))
%     %Include all old satellites, and update in case of a new reading
%     %appearing, otherwise keep the previous one
%     if (s1(t1(i)).ToW==s2(t2(i)).ToW)
%         s1sortedID       = sortrows(s1(t1(i)).data, 2);
%         s2sortedID       = sortrows(s2(t2(i)).data, 2);
%         [~, s1UniqueIdx] = unique(s1sortedID.svID, 'first');    
%         [~, s2UniqueIdx] = unique(s2sortedID.svID, 'first');
%         s1sortedUnique   = s1sortedID(s1UniqueIdx,:);
%         s2sortedUnique   = s2sortedID(s2UniqueIdx,:);
%         [~,idx1, idx2]   = intersect(s1UniqueIdx, s2UniqueIdx);
%         s1Unique         = sortrows(s1sortedUnique(idx1,:),1);
%         s2Unique         = sortrows(s2sortedUnique(idx2,:),1);
%         %Adding the previous data first, and then updating with new data
%         s1shared(i).data = s1Prev;
%         s2shared(i).data = s2Prev;
%         if(~(isempty(s1Prev)||(isempty(s2Prev))))
%         [~, i1prev, i1upd]      = intersect(s1Prev.svID, s1Unique.svID);
%         [~, i2prev, i2upd]      = intersect(s1Prev.svID, s1Unique.svID);
%         s1shared(i).data(i1prev,:)=s1Unique(i1upd,:);
%         s2shared(i).data(i2prev,:)=s2Unique(i2upd,:);
%         else
%         s1shared(i).data = s1Unique;
%         s2shared(i).data = s2Unique;
%         end
%         s1Prev=s1shared(i).data;
%         s2Prev=s2shared(i).data;
%     else
%         %keyboard
%     end
% end
% 
% 

    