function [s1shared, s2shared]=findSharedSV(s1,s2,t1,t2)
%At each time instance, find the satellites which are observed in both
%recievers.

%ISSUE, may be overlap, I will remove all duplicates of svID elements, will
%have to check that angles are the same later
s1shared=s1(t1);
s2shared=s2(t2);

for i=1:min(length(t1), length(t2))
    if (s1(t1(i)).ToW==s2(t2(i)).ToW)
        s1sortedID       = sortrows(s1(t1(i)).data, 2);
        s2sortedID       = sortrows(s2(t2(i)).data, 2);
        [~, s1UniqueIdx] = unique(s1sortedID.svID, 'first');    
        [~, s2UniqueIdx] = unique(s2sortedID.svID, 'first');
        s1sortedUnique   = s1sortedID(s1UniqueIdx,:);
        s2sortedUnique   = s2sortedID(s2UniqueIdx,:);
        [~,idx1, idx2]   = intersect(s1UniqueIdx, s2UniqueIdx);
        s1Unique         = sortrows(s1sortedUnique(idx1,:),1);
        s2Unique         = sortrows(s2sortedUnique(idx2,:),1);
        s1shared(i).data = s1Unique;
        s2shared(i).data = s2Unique;
    else
        %keyboard
    end
end



    