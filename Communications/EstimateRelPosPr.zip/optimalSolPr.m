function [tVec, r_ab, dt]=optimalSolPr(D,u)
r_ab=zeros(3,140);
dt=zeros(1, 140);
c=299792458;
tVec=zeros(1,min(size(u,2),size(D,2)));
for i=1:min(size(u,2),size(D,2))
    try
    [~,iD,iu]=intersect(D(i).sat, u(i).sv);
    H=[u(i).dir(iu,:) c*ones(length(iu),1)];
    if length(iD)>=4
        dP=inv(H'*H)*H'*D(i).dp(iD);
        r_ab(:,i)=dP(1:3);
        dt(i)=dP(4);
    else
        r_ab(:,i)=r_ab(:,i-1);
        dt(i)=dt(i-1);
    end
    tVec(i)=D(i).ToW;
    catch EM
        EM
        keyboard
    end
end
tVec=tVec-D(1).ToW;
