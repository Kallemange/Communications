function plotResultPr(r_ab, tVec, dt)
figure
sgtitle('Distance in each direction')
subplot(311)
plot(tVec,r_ab(1,:))
ax1=gca;
subplot(312)
plot(tVec,r_ab(2,:))
ax2=gca;
subplot(313)
plot(tVec,r_ab(3,:))
ax3=gca;
linkaxes([ax1 ax2 ax3]);
figure
d=vecnorm(r_ab, 1);
plot(tVec,d)
xlabel('Euclidean distance')
figure
plot(tVec,dt)
title('estimated relative clockdrift between recievers')
