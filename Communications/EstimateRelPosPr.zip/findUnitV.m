function u=findUnitV(s1)
%Function to find the unit vector pointing towards the SV in question
%The formula to produce these directional vectors is given by
%[sin a cos b, cos a cos b, sin b]'

for i=1
    elev     = s1(i).data.elev;
    azim     = s1(i).data.azim;
    u.dir    = [sind(azim).*cosd(elev) cosd(azim).*cosd(elev) sind(elev)];
    u.sv     = s1(i).data.svID;
    u.ToW    = s1.ToW;
end
