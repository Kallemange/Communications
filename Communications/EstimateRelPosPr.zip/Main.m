%% Karl Lundin Master thesis project

%% Part1 
%Estimating the relative positions and the drift over time utilizing
%the global positions provided by the sensor
%Several measurements were made, with stationary and moving recievers,
%The relative positional estimates are presented based on the data from the
%IS units own calculations
close all, clear all, clc
%% Measurements from INS-log at stationary 1m
T1=readtable('Uggleviken0312/1m1/Ins.csv');
T2=readtable('Uggleviken0312/1m2/Ins.csv');
%% 
relativeGPSPosINS(T1,T2, 'ned', 1, 1 );
%% Measurements from INS-log at stationary 2m
close all, clear all, clc
T1=readtable('Uggleviken0312/2m1/Ins.csv');
T2=readtable('Uggleviken0312/2m2/Ins.csv');
%%
relativeGPSPosINS(T1,T2, 'lla', 1, 2 );
%% Measurements from INS-log at stationary 7m
close all, clear all, clc
T1=readtable('Uggleviken0312/7m1/Ins.csv');
T2=readtable('Uggleviken0312/7m2/Ins.csv');
%%
relativeGPSPosINS(T1,T2, 'lla', 1, 7);
%% Measurements from INS-log while walking around
close all, clear all, clc
T1=readtable('Uggleviken0312/prom1/Ins.csv');
T2=readtable('Uggleviken0312/prom2/Ins.csv');
%%
relativeGPSPosINS(T1,T2, 'lla', 1, 0.5);
%% Part 2
%Estimating the position of the sensors using the satellite information
%directions, and the pseudorange measurements
close all, clear all, clc
%%
[sat1 sat2 raw1 raw2] = rSatRawData('Uggleviken0312/','1m');
%%
[sat1 sat2 raw1 raw2] = rSatRawData('Uggleviken0312/','2m');
%%
[sat1 sat2 raw1 raw2] = rSatRawData('Uggleviken0312/','7m');
%%
[sat1 sat2 raw1 raw2] = rSatRawData('Uggleviken0312/','prom');
%% Calculate distance from pseudorange measurements
%IN satellite data[2], raw data[2]
%OUT pseudo range distance between reciever ab, unit vector to satellites
[D u]                 = estPosFromPr(sat1,sat2, raw1, raw2);
%% Estimate the relative position from the pr-measurements
%Optimal solution calculated as inv(H'H)H'D for ?(x,y,z,T)
%IN pseudorange distance, directions to satellites
%OUT time since start, distance in xyz, clock-drift over time
[tVec, r_ab, dt]      = optimalSolPr(D,u); 
%% Plot the results 
plotResultPr(r_ab,tVec,dt)
%% Next step: gradient descent, expected to decrease cost, 
%calculations should be equivalent
posVec=[];
xVec=zeros(3,1);
dtVec=[0];
for i=1
    [posVec dt]=calcPosGradientDescent(D{i},u{i}, xVec(:,end),dtVec(end));
end
%C:\Users\kalle\Documents\KTHKurser\Exjobb\Background research\Exercises\localization-exercises-files-20161006
