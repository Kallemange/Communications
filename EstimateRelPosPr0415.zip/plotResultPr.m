function plotResultPr(r_ab, tVec, trueDir)
figure
hold on
sgtitle('Distance in each direction')
NEDvec=['N'; 'E'; 'D'];
for i=1:3
subplot(4,1,i)
plot(tVec,r_ab(i,:))
xlabel(strcat(NEDvec(i), '-direction, mean: ', ...
        num2str(mean(r_ab(i,:))) ...
))
end
subplot(414)
d=vecnorm(r_ab, 1);
plot(tVec,d)
xlabel('Euclidean distance')


labelVec = ['N-direction'; 'E-direction'; 'D-direction'];
numVec   = ['0', '1', '2'];
figure
sgtitle(strcat('Histogram drift relative estimates from pR, true distance 10m in ', trueDir, '-direction'))
for i=1:3
    subplot(3,1,i)
    histogram(r_ab(i,:)-mean(r_ab(i,:)),'Normalization','probability', 'DisplayStyle', 'stairs');
    hold on
    xlabel(strcat(labelVec(i,:),', mean 2= ', num2str(round(mean(r_ab(i,:)),2)), '[m]', ...
            ', \sigma^2= ', num2str(round(var(r_ab(i,:)),2))  ...
        ))
    
    
end
figure
sgtitle(strcat('Histogram drift relative estimates from pR, true distance 10m in ', ...
                trueDir, '-direction'))
hold on
colors=['r', 'g', 'b'];
meanstr='mean: ';
varstr ='variance: ';
for i=1:3
    histogram(r_ab(i,:),'Normalization','probability', 'DisplayStyle', 'stairs');    
    meanstr= strcat(meanstr,32, num2str(round(mean(r_ab(i,:)),1)), ', ', 32);
    varstr= strcat(varstr, 32, num2str(round(var(r_ab(i,:)),1)), ', ', 32);
end
legend(labelVec)
xlabel(strcat('NED: ',32,  meanstr(1:end-2), '[m]',32, varstr(1:end-2)))